# Research Data and Numerical Results
## Closed-Form Power Allocation for Floor-Protected Hybrid Digital–Analog Video Transmission with Receiver-Side Prediction

**Manuscript authors:** Anonymous (withheld for double-blind peer review)  
**Author affiliation:** Withheld for double-blind peer review  

> **Anonymity notice:** This README is prepared in an anonymized form for an IEEE-style double-blind review workflow. Author names, institutional affiliations, personal email addresses, and corresponding-author identifiers are intentionally omitted. Check the target IEEE publication's data-sharing and repository-anonymity requirements before making the dataset publicly identifiable or linking it to an author profile.
**Dataset type:** Simulation-derived numerical data, analytical evaluation outputs, and pilot video-transmission results  
**Primary formats:** CSV and JSON

---

## 1. Dataset purpose and scope

This repository contains the numerical data associated with the figures and selected tables in the manuscript *Closed-Form Power Allocation for Floor-Protected Hybrid Digital–Analog Video Transmission with Receiver-Side Prediction*.

The files preserve numerical values used to construct the manuscript's plots, summarize numerical checks of the analytical developments, and report selected results from the video-transmission pilot. They are intended to support inspection of the reported numerical evidence, figure reconstruction, and computational reproducibility.

The research studies a floor-protected hybrid digital–analog transmission architecture. A self-contained digital floor provides a minimum reconstruction-quality reference when decoded. A linear analog refinement layer uses the remaining channel resources. At the receiver, each transform coefficient is reconstructed by combining receiver-side prediction, the digital-floor reconstruction, and the analog observation through a conditional-mean estimator. Under the manuscript's Gaussian and first-order Gauss–Markov assumptions, the receiver recursion has a scalar Kalman-filter interpretation.

The numerical material covers:

- Riccati recursion and steady-state prediction error;
- prediction-aware variance and power allocation;
- pre-channel distortion and bandwidth-induced truncation;
- amplitude clipping, Bussgang gain, distortion, and optimal back-off;
- channel-estimation error and imperfect-CSI allocation;
- pilot-length/rate trade-offs;
- floor-power splitting and controller convergence;
- mismatch-regret evaluation;
- selected pilot-video results and reference comparisons.

**This deposit is not a raw-video dataset.** The CSV and JSON files are numerical outputs or derived data. The manuscript's video pilot uses a previously compressed source clip that was resized and cropped before evaluation. The limitations and scope of that pilot are described in Section 9 below.

---

## 2. Contents

The dataset consists of 18 CSV files and one JSON file.

| Directory / group | Files | Main subject |
|---|---:|---|
| `Figure_1/` | 3 | Riccati recursion and allocation data |
| `Figure_2/` | 2 | Pre-channel distortion and bandwidth decomposition |
| `Figure_3/` | 3 | Clipping, Bussgang validation, and SNDR |
| `Figure_4/` | 4 | Channel-estimation precision, allocation, and pilot rates |
| `Figure_5/` | 2 | Floor-power controller and Equation (24) |
| `Tables/` | 3 | Floor sweep, mismatch regret, and pilot reference results |
| `Evaluation/` | 1 | JSON pilot-evaluation results |

The directory names above are a recommended organization. The filenames listed in Section 4 are the authoritative filenames. If the files are deposited in a single directory rather than these subdirectories, the same names and associations remain applicable.

---

## 3. Relationship to the manuscript

The package's filename prefixes are organizational labels; they are **not a replacement for the manuscript's figure numbering**. The following cross-reference identifies the intended manuscript location.

| Dataset file(s) | Manuscript location | Content |
|---|---|---|
| `Figure_1a_Riccati_Data.csv` | Figure 1 | Riccati recursion and convergence of receiver-side prediction error |
| `Figure_1b_Variance_Allocation.csv` | Figure 2 | Prediction-aware variance allocation and active-set structure |
| `Figure_1c_Power_Allocation_Data.csv` | Figure 3 | Equal-energy comparison of proposed, floor-only/no-side-information, and SoftCast-type allocations |
| `Figure_2a_bandwidth_data.csv` | Figure 4(a) | Pre-channel distortion fraction versus total bandwidth ratio |
| `Figure_2b_decomposition_data.csv` | Figure 4(b) | Bandwidth-forced and energy-forced contributions to pre-channel distortion |
| `figure3_monte_carlo.csv` | Figure 5 analytical/Monte Carlo validation | Monte Carlo verification of limiter gain and distortion |
| `figure3_panel_a_curve.csv` | Figure 5(a) | Bussgang gain and normalized distortion versus limiter back-off |
| `figure3_panel_b_curves.csv` | Figure 5(b) | SNDR versus back-off for different peak-SNR operating points |
| `figure3_table_iii_reproduction.csv` | Table III | Optimal back-off and corresponding SNDR results |
| `figure4_panel_a_precision_ceiling.csv` | Figure 6(a) | Effective-SINR/precision ceiling under channel-estimation error |
| `figure4_panel_b_allocations.csv` | Figure 6(b) | Allocation/distortion comparison under perfect and imperfect CSI |
| `figure4_panel_b_summary.csv` | Figure 6(b), numerical summary | Aggregate allocation and distortion statistics for the CSI cases |
| `figure4_panel_c_pilot_rates.csv` | Figure 6(c) | Pilot-count and achievable-rate relationship |
| `figure5_controller_local_linearization.csv` | Figure 7(b) | Damped and undamped floor-power controller trajectories |
| `figure5_eq24_dense.csv` | Figure 7(b), Equation (24) numerical comparison | Dense evaluation of the two sides of the floor-power stationarity condition |
| `table_v_floor_sweep.csv` | Table V | Floor-SNR sweep, equivalent throughput, and marginal-cost balance |
| `table_vi_mismatch_regret.csv` | Table VI | Empirical mismatch regret, adversarial-corner result, and analytical bound |
| `table_x_reference.csv` | Table X; also supports the pilot comparison in Figure 8(a) | Pilot PSNR results for the proposed design and reference configurations |
| `eval_res_baseline.json` | Table X and pilot-evaluation results | Structured results for the proposed design and ablation/reference modes |

The manuscript's Figure 8 presents the video-pilot performance and model-validation results. `table_x_reference.csv` and `eval_res_baseline.json` provide structured numerical results for the corresponding pilot comparison. The JSON file does not replace the separate H.264 measurements or any source data not included in this deposit.

---

## 4. File inventory and data dictionary

### 4.1 Riccati recursion and allocation

#### `Figure_1a_Riccati_Data.csv`

**Purpose:** Numerical trajectories for the scalar prediction-measurement recursion and comparison with the analytical steady-state value.

| Column | Description |
|---|---|
| `a` | Gauss–Markov loop gain |
| `omega` | Innovation variance, \(\omega\) |
| `beta` | Measurement precision parameter used in the recursion |
| `gop` | Group-of-pictures iteration index |
| `distortion` | Recursively evaluated distortion/error variance |
| `steady_state` | Analytical steady-state distortion for the corresponding parameter set |

The file supports the convergence illustration in manuscript Figure 1. The plotted trajectories demonstrate the dependence of convergence on temporal correlation.

#### `Figure_1b_Variance_Allocation.csv`

**Purpose:** Coefficient-wise data for the prediction-aware variance and active-set representation.

| Column | Description |
|---|---|
| `coefficient_index` | Transform-coefficient index |
| `lambda_i` | Source/stationary variance \(\lambda_i\) |
| `omega_i` | Innovation variance \(\omega_i\) |
| `D_previous_steady_state` | Previous-group steady-state distortion used for the prediction calculation |
| `mu_i` | Prediction-conditioned variance \(\mu_i\) |
| `vartheta_i` | Floor residual variance \(\vartheta_i\) |
| `kappa_i` | Posterior variance before analog refinement \(\kappa_i\) |
| `pinned_level` | Allocation pinning level associated with the optimality condition |
| `D_allocated` | Allocated posterior distortion \(D_i\) |
| `energy_i` | Per-component refinement energy \(E_i\) |
| `gain_squared` | Analog gain squared \(g_i^2\) |
| `noise_variance` | Per-component noise variance |
| `floor_coded` | Boolean indicator for floor-coded coefficients |
| `analog_active` | Boolean indicator for coefficients receiving positive analog refinement |
| `energy_truncated` | Boolean indicator for energy-truncated coefficients |

The file supports manuscript Figure 2 and its logarithmic representation of the source variance, prediction-conditioned variance, floor residual, posterior variance, and allocated distortion.

#### `Figure_1c_Power_Allocation_Data.csv`

**Purpose:** Coefficient-wise comparison of three allocation configurations under the common synthetic source-variance field and refinement-energy budget.

| Column | Description |
|---|---|
| `coefficient_index` | Transform-coefficient index |
| `lambda_i` | Source variance \(\lambda_i\) |
| `omega_i` | Innovation variance \(\omega_i\) |
| `floor_threshold` | Digital-floor threshold \(\theta_F\) |
| `floor_residual_vartheta_i` | Floor residual variance \(\vartheta_i\) |
| `proposed_mu_i` | Prediction-conditioned variance for the proposed design |
| `proposed_kappa_i` | Posterior variance before analog refinement for the proposed design |
| `proposed_energy_E_i` | Per-component energy for the proposed design |
| `proposed_gain_squared_g2` | Analog gain squared for the proposed design |
| `proposed_distortion_D_i` | Allocated distortion for the proposed design |
| `floor_no_si_kappa_i` | Posterior variance for the floor-protected design without side information |
| `floor_no_si_energy_E_i` | Per-component energy for the floor-protected design without side information |
| `floor_no_si_gain_squared_g2` | Analog gain squared for the floor-protected design without side information |
| `floor_no_si_distortion_D_i` | Allocated distortion for the floor-protected design without side information |
| `softcast_kappa_i` | Posterior/source variance for the SoftCast-type reference without floor or side information |
| `softcast_energy_E_i` | Per-component energy for the SoftCast-type reference |
| `softcast_gain_squared_g2` | Analog gain squared for the SoftCast-type reference |
| `softcast_distortion_D_i` | Allocated distortion for the SoftCast-type reference |

The manuscript describes this as an equal-energy comparison with \(P=1649.7\) over \(k=20{,}000\) coefficients. The three configurations are the proposed floor-plus-prediction design, floor protection without side information, and a SoftCast-type allocation without a floor or side information.

### 4.2 Pre-channel distortion and bandwidth decomposition

#### `Figure_2a_bandwidth_data.csv`

**Purpose:** Pre-channel distortion fraction across total bandwidth-ratio operating points.

| Column | Description |
|---|---|
| `total_bandwidth_ratio` | Total real-dimension bandwidth ratio \(2n_{\mathrm{eff}}/k\) |
| `proposed_beta_up` | Pre-channel distortion fraction for the proposed design |
| `proposition7_lower_bound` | Bandwidth-forced lower bound from Proposition 7 |
| `linear_analog_beta_up` | Pre-channel distortion fraction for the linear-analog reference |
| `proposed_feasible` | Boolean indicator of proposed-design feasibility at the operating point |

A missing (`NaN`) proposed-design value denotes an operating point for which the proposed floor-constrained design is marked infeasible; it is not a measured zero.

#### `Figure_2b_decomposition_data.csv`

**Purpose:** Mean decomposition of the pre-channel distortion fraction at the reported SNR points.

| Column | Description |
|---|---|
| `snr_db` | Channel SNR in dB |
| `beta_up_mean` | Mean total pre-channel distortion fraction |
| `proposition7_bandwidth_forced_mean` | Mean bandwidth-forced contribution |
| `energy_forced_remainder_mean` | Mean remaining energy-forced contribution |

The two contribution columns represent the decomposition described in manuscript Figure 4(b).

### 4.3 Amplitude clipping and Monte Carlo validation

#### `figure3_monte_carlo.csv`

**Purpose:** Monte Carlo comparison of the limiter's Bussgang gain and normalized distortion against their closed-form values.

| Column | Description |
|---|---|
| `lambda_linear` | Linear back-off parameter \(\Lambda=A^2/\sigma^2\) |
| `backoff_db` | Back-off in dB |
| `alpha_mc` | Monte Carlo estimate of the Bussgang gain |
| `alpha_closed_form` | Closed-form Bussgang gain |
| `alpha_abs_error` | Absolute difference between Monte Carlo and closed-form gain |
| `distortion_mc` | Monte Carlo normalized distortion |
| `distortion_closed_form` | Closed-form normalized distortion |
| `distortion_abs_error` | Absolute difference between Monte Carlo and closed-form normalized distortion |
| `complex_draws` | Number of complex random draws |
| `seed` | Random-number-generator seed |

The manuscript's numerical verification reports \(4\times10^6\) complex draws for the limiter checks. The actual draw count and seed are recorded in each row.

#### `figure3_panel_a_curve.csv`

**Purpose:** Dense curve data for limiter gain and normalized distortion.

| Column | Description |
|---|---|
| `backoff_db` | Limiter back-off in dB |
| `lambda_linear` | Linear back-off parameter \(\Lambda\) |
| `alpha` | Bussgang gain |
| `normalized_distortion_variance` | Distortion variance normalized by input variance |

#### `figure3_panel_b_curves.csv`

**Purpose:** SNDR curves across peak-SNR operating points.

| Column | Description |
|---|---|
| `peak_snr_db` | Peak SNR in dB |
| `backoff_db` | Back-off in dB |
| `sndr_db` | Signal-to-noise-and-distortion ratio in dB |

#### `figure3_table_iii_reproduction.csv`

**Purpose:** Numerical reproduction of the optimal-back-off results reported in Table III.

| Column | Description |
|---|---|
| `peak_snr_db` | Peak SNR in dB |
| `lambda_star` | Optimal linear back-off parameter |
| `lambda_star_db` | Optimal back-off in dB |
| `sndr_star_db` | SNDR at the optimal back-off, in dB |
| `ideal_snr_same_backoff_db` | Ideal reference SNR at the same back-off, in dB |
| `shortfall_db` | Difference between the ideal reference and the achieved SNDR, in dB |

### 4.4 Channel-estimation error and pilot-rate data

#### `figure4_panel_a_precision_ceiling.csv`

**Purpose:** Effective-SINR and precision-ceiling evaluation under channel-estimation error.

| Column | Description |
|---|---|
| `component_energy_u` | Allocated component energy \(u\) |
| `sigma_e2` | Channel-estimation error variance \(\sigma_e^2\) |
| `effective_sinr_db` | Effective SINR in dB |
| `ceiling_db` | Precision/SINR ceiling in dB where defined |

A missing (`NaN`) ceiling value indicates that the ceiling is not defined for that row's parameter combination in the exported data.

#### `figure4_panel_b_allocations.csv`

**Purpose:** Component-wise allocation comparison for perfect CSI and multiple channel-estimation error variances.

| Column | Description |
|---|---|
| `component_rank_descending_lambda` | Component rank after sorting source variance in descending order |
| `lambda` | Source variance |
| `vartheta` | Floor residual variance |
| `kappa` | Posterior variance before analog refinement |
| `perfect_csi` | Allocated component energy under perfect CSI |
| `sigma2_0.00249376558603` | Allocated component energy for the indicated estimation-error variance |
| `sigma2_0.0243902439024` | Allocated component energy for the indicated estimation-error variance |
| `sigma2_0.0732600732601` | Allocated component energy for the indicated estimation-error variance |

The numeric suffixes in the three `sigma2_...` column names are the corresponding \(\sigma_e^2\) parameter values. They are retained as exported to preserve the exact data-column identifiers.

#### `figure4_panel_b_summary.csv`

**Purpose:** Aggregate summary of the imperfect-CSI allocation cases.

| Column | Description |
|---|---|
| `sigma_e2` | Channel-estimation error variance |
| `dual_xi` | Dual multiplier \(\xi\) |
| `total_energy` | Total allocated energy |
| `total_distortion_sum` | Sum of component distortions |
| `active_components` | Number of active components |
| `max_component_energy` | Maximum component energy |

#### `figure4_panel_c_pilot_rates.csv`

**Purpose:** Pilot-count/rate evaluation for different coherence-block lengths and mean-SNR operating points.

| Column | Description |
|---|---|
| `m` | Coherence-block length |
| `mean_snr_db` | Mean SNR in dB |
| `pilot_count` | Number of pilot symbols |
| `rate_bits_per_channel_use` | Evaluated rate in bits per channel use |

### 4.5 Floor-power split and controller

#### `figure5_controller_local_linearization.csv`

**Purpose:** Iteration trajectories for the floor-power controller under different damping factors and initial floor-SNR values.

| Column | Description |
|---|---|
| `iteration` | Controller iteration index |
| `tau=1, start=6 dB` | Undamped trajectory initialized at 6 dB |
| `tau=1, start=14 dB` | Undamped trajectory initialized at 14 dB |
| `tau=0.66, start=6 dB` | Damped trajectory initialized at 6 dB |
| `tau=0.66, start=14 dB` | Damped trajectory initialized at 14 dB |

The manuscript reports a local slope of approximately \(-0.52\), with damping \(\tau=0.66\) reaching the fixed point in two steps in the illustrated synthetic-model experiment.

#### `figure5_eq24_dense.csv`

**Purpose:** Dense numerical evaluation of the two sides of the first-order floor-power stationarity condition in Equation (24).

| Column | Description |
|---|---|
| `gamma_f_db` | Floor SNR \(\gamma_F\) in dB |
| `lhs_exact_eq24` | Exact left-hand side \((1+\gamma_F)\ln(1+\gamma_F)-\gamma_F\), evaluated at the corresponding linear SNR |
| `rhs_pchip_from_table_v` | Right-hand side obtained by PCHIP interpolation from the Table V values |

The crossing of these two quantities identifies the numerical stationary operating point. The interpolation column is an interpolated representation, not an independent measurement.

### 4.6 Tabulated numerical results

#### `table_v_floor_sweep.csv`

**Purpose:** Synthetic-model floor-SNR sweep associated with manuscript Table V.

| Column | Description |
|---|---|
| `gamma_f_db` | Floor SNR in dB |
| `nf_over_n` | Fraction of channel uses allocated to the floor, \(n_F/n\) |
| `teq_mbps` | Rate-distortion-equivalent throughput in Mbps |
| `eq24_lhs` | Left-hand side of Equation (24) |
| `eq24_rhs` | Right-hand side of Equation (24) |

#### `table_vi_mismatch_regret.csv`

**Purpose:** Mismatch-regret results associated with manuscript Table VI.

| Column | Description |
|---|---|
| `delta` | Mismatch magnitude \(\delta\) |
| `random_draws` | Worst observed regret ratio over random instances |
| `adversarial_corner` | Regret ratio for the reported adversarial-corner construction |
| `bound` | Analytical upper bound \((1+\delta)^2\) |

The random-draw and adversarial-corner values are numerical evaluations; `bound` is the analytical comparison bound stated in the manuscript.

#### `table_x_reference.csv`

**Purpose:** Structured pilot PSNR results corresponding to manuscript Table X.

| Column | Description |
|---|---|
| `snr_db` | Channel SNR in dB |
| `series` | Transmission configuration or reference series |
| `status` | Evaluation status, including infeasibility where applicable |
| `mean_psnr_db` | Mean PSNR over groups, in dB |
| `minimum_psnr_db` | Minimum PSNR over groups, in dB |
| `source` | Manuscript table/source label retained in the export |

Missing PSNR values for rows marked `infeasible` are intentional and must not be interpreted as zero-valued performance.

### 4.7 Structured evaluation output

#### `eval_res_baseline.json`

**Purpose:** Machine-readable pilot evaluation results for the proposed design and ablation/reference modes.

The JSON object uses keys of the form:

`<mode>|<snr_db>`

The included modes are:

- `ours`
- `ours_noSI`
- `nofloor_SI`
- `softcast`

Each non-null result object contains:

| Key | Description |
|---|---|
| `psnr` | Mean PSNR over the evaluated groups, in dB |
| `psnr_min` | Minimum group PSNR, in dB |
| `model` | Model-predicted PSNR, in dB |
| `nF` | Fraction of effective channel uses allocated to the floor |

A JSON `null` indicates that the corresponding operating point was infeasible in the evaluation. The file does not contain all H.264 reference measurements; consult `table_x_reference.csv` for the structured Table X comparison.

---

## 5. Numerical conventions and interpretation

1. **Logarithmic quantities:** Columns ending in `_db` or explicitly described as dB are expressed in decibels. SNR and SNDR values are not linear ratios unless the column name or description explicitly says otherwise.
2. **Variance and distortion:** Variance and distortion columns are in the numerical units of the corresponding source/model representation. They should not be treated as pixel-domain MSE unless the manuscript's relevant calculation defines them that way.
3. **Power and energy:** Component-energy and gain-squared columns follow the allocation definitions used in the manuscript. They are not interchangeable.
4. **Boolean fields:** `True`/`False` columns encode membership or feasibility flags, not numeric measurements.
5. **Missing values:** `NaN` and JSON `null` represent undefined, unavailable, or infeasible entries as applicable. They must not be silently replaced by zero.
6. **Averaging:** Where the manuscript specifies a mean or minimum over groups, the corresponding table/JSON description identifies that aggregation. Do not infer a different aggregation from the CSV row count alone.
7. **Synthetic versus pilot data:** The allocation, clipping, CSI, pilot-rate, floor-sweep, and controller datasets include synthetic-model or numerical-analysis experiments. The pilot video results are a separate evaluation and should not be presented as broad natural-video validation.

---

## 6. Experimental context for the video pilot

The manuscript's pilot evaluation uses one previously compressed animated clip, originally 1280 × 720 at 25 frames per second, decoded and processed to 640 × 352, YUV 4:2:0, with 128 frames and 16 groups of \(G=8\) frames.

The manuscript reports the following processing command for preparing the raw pilot input from `bigbuckbunny.mp4`:

```bash
ffmpeg -i bigbuckbunny.mp4 \
  -vf "scale=640:360:flags=area,crop=640:352:0:4" \
  -frames:v 128 -pix_fmt yuv420p \
  -f rawvideo bbb352.yuv
```

The pilot's reported operating conditions include:

- Frame rate: 25 frames per second.
- Group length: 8 frames.
- Group duration: 0.32 seconds.
- Number of groups: 16.
- Channel model: additive white Gaussian noise (AWGN).
- Total effective channel uses: approximately 226,113 complex uses per group after overhead.
- Total bandwidth ratio: approximately \(2n_{\mathrm{eff}}/k \approx 0.17\).
- Side-information predictor: zero-motion prediction based on the previous reconstructed group.
- Floor sizing: oracle knowledge of the tested SNR in the reported pilot.
- Noise realizations: one realization for the reported video comparison.

The manuscript states that the source was previously compressed, animated, and downscaled. The absolute PSNR values therefore should not be interpreted as representative of uncompressed natural video or as evidence across a broad video corpus.

The manuscript's reproduction instructions identify `evallab.py`, `runeval.py`, and `runh264.py` as the pilot implementation scripts. The full source code and the raw video input are not included in this numerical-data deposit unless separately supplied.

---

## 7. Reproducibility and software context

The manuscript's computational implementation uses Python and the following scientific/software components, as evidenced by the accompanying implementation:

- Python
- NumPy
- SciPy
- FFmpeg (including `libx264` for the H.264 reference experiment)
- `imageio-ffmpeg` for locating the FFmpeg executable in the H.264 evaluation script

The source modules supplied with the research implementation are:

- `floorlab.py`
- `evallab.py`
- `splitlab.py`
- `ctrllab.py`
- `runeval.py`
- `runh264.py`

The CSV and JSON files in this deposit are result/data artifacts. They are not, by themselves, a complete executable reproduction package. Full reruns may require the source modules, compatible package versions, FFmpeg/libx264, the source video, and the raw YUV preparation step.

The manuscript reports these pilot reproduction commands:

```bash
python runeval.py grid
python runeval.py margin
python runeval.py floor
python runh264.py
```

These commands require the corresponding source files and input data in the execution environment. They should not be expected to run from this data-only deposit in isolation.

For a fully reproducible release, the code repository should separately record exact Python and package versions, FFmpeg version/build configuration, source-video provenance, and any additional run configuration or random seeds. The Monte Carlo seed is recorded in `figure3_monte_carlo.csv`.

---

## 8. Suggested citation

If this dataset is assigned a DOI, cite the deposited dataset using the repository's generated citation metadata. Until a DOI and version are assigned, the following provisional citation identifies the associated manuscript and dataset:

Anonymous. (n.d.). *Research data and numerical results for: Closed-form power allocation for floor-protected hybrid digital–analog video transmission with receiver-side prediction* [Data set]. [Repository name]. [DOI to be assigned].

Replace the date, repository name, and DOI placeholders with the metadata generated by the selected repository. Do not cite this provisional form as a final DOI citation until the deposit is published.

---

## 9. Scope, limitations, and responsible interpretation

The numerical results should be interpreted within the assumptions and experimental scope stated in the manuscript.

- The analytical model uses Gaussian transform coefficients and a first-order Gauss–Markov evolution model.
- The pilot uses one previously compressed animated clip, 16 groups, AWGN, one noise realization, and a zero-motion side-information predictor.
- The floor is sized at the true tested SNR in the reported pilot; fading-induced floor outage and the digital cliff are not exercised.
- Encoder statistics are estimated per group from source frames, with the associated metadata cost counted.
- The digital H.264 reference configurations use oracle rate adaptation and an ideal capacity-achieving channel code in the comparison described by the manuscript.
- A learned joint source-channel coding baseline was not evaluated.
- Encoder complexity, real-system latency, and amplifier behavior were not measured in the video pilot.
- The manuscript explicitly treats several further evaluations—including raw sequences across multiple motion classes, fading and delayed feedback, decoder-side motion compensation, and software-defined-radio measurements—as future work rather than completed experiments.

Accordingly, this dataset supports inspection and reconstruction of the reported numerical results. It does not establish performance over arbitrary video content, fading channels, real hardware, or the additional scenarios identified as future work.

---

## 10. File integrity and versioning

For a formal research-data release:

1. Preserve the supplied filenames and column names.
2. Do not overwrite source CSV/JSON files with rounded or manually edited versions.
3. Keep the README and all data files in the same versioned deposit.
4. Record a release date and version identifier in the repository metadata.
5. If a file is corrected, publish a new version and describe the change in the release notes.
6. Generate and retain SHA-256 checksums for the deposited files if the repository does not provide file-integrity metadata automatically.

**Dataset version:** 1.0 (initial deposit; assign only when the repository release is finalized)  
**Associated manuscript:** *Closed-Form Power Allocation for Floor-Protected Hybrid Digital–Analog Video Transmission with Receiver-Side Prediction*  
**Author/contact information:** Withheld for double-blind peer review. Add the authorized contact information only after the review process, if required by the journal or repository.
